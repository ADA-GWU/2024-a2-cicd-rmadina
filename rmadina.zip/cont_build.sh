mvn clean package
docker build -t springio/webtest .
